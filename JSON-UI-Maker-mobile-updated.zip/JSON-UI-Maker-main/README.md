# JSON-UI Builder

A browser-based visual editor for Minecraft Bedrock JSON UI forms.

## Build

```bash
npm install
npm run check
npm test
npm run build
```

The build writes the compiled JavaScript modules to `dist/`. Serve this folder as a static website from a local web server or static hosting provider; opening `index.html` directly may restrict file and browser APIs.

## Mobile use

On screens up to 900px wide, the editor switches to a four-tab layout:

- **Editor**: pan around the large Bedrock form canvas and drag elements with touch.
- **Elementos**: add, delete, reset and browse elements.
- **Propriedades**: edit the selected element's settings.
- **Código**: generate scripts and inspect bindings.

For editing a wide form on a phone, use landscape orientation or pinch-zoom in the browser. The canvas remains at its native 1500 × 844 CSS-pixel workspace size so exported positions are not changed by responsive styling.

## Browser notes

The main editor is client-side. Account and shared-preset features load SQL.js from its hosted distribution, so those features require an internet connection. Clipboard access uses the Clipboard API when available and a browser fallback otherwise.
