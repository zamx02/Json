# Construtor JSON UI — Minecraft Bedrock

Editor visual no navegador para criar, reorganizar e exportar interfaces JSON UI do Minecraft Bedrock. Interface em português do Brasil, tema inspirado na Ore UI e ferramentas adaptadas para celular.

## Executar / publicar

O projeto é estático e pode ser publicado no GitHub Pages. Na raiz do repositório, mantenha `index.html`, `style.css`, `background.webp`, `assets/`, `fonts/` e `dist/`.

Para compilar o TypeScript após alterações em `src/`:

```bash
npm install
npm run check
npm test
npm run build
```

O editor local não exige cadastro, login ou banco remoto. A edição, as propriedades, a árvore, o histórico, a importação e a exportação são executados no navegador.

## Celular

- Use as abas inferiores **Editor**, **Elementos**, **Atributos** e **Código**.
- Na área Editor, ajuste o zoom pelos controles, use Enquadrar e acesse desfazer/refazer, copiar/colar, excluir e grade.
- Na aba Elementos, adicione componentes, importe arquivos e reorganize a hierarquia. Segure um elemento por um instante e arraste para dentro de um painel compatível.
- A área de trabalho mantém as coordenadas nativas de 1500 × 844 para que a escala visual não altere as posições exportadas.

## Ícones

Os ícones de itens vanilla são carregados de `Mojang/bedrock-samples` e precisam de conexão à internet. Consulte `ASSET-CREDITS.md`.
