import { GLOBAL_FILE_SYSTEM, images, setFileSystem } from "../index.js";
import { Notification } from "../ui/notifs/noficationMaker.js";

export class FileUploader {
    private static getFilePath(file: File): string {
        const relativePath = file.webkitRelativePath || (file as any)._webkitRelativePath;
        return relativePath || `ui/${file.name}`;
    }

    public static addToFileSystem(file: File): void {
        const dir = this.getFilePath(file);
        const parts = dir.split("/");

        const fs = GLOBAL_FILE_SYSTEM;
        let current = fs;

        for (const part of parts) {
            if (part === "") continue;
            if (!current[part]) current[part] = {};

            current = current[part];
        }

        setFileSystem(fs);
    }

    /**
     * Handles the event when a file is selected in the "Open Pack" dialog.
     * Loads the selected pack into the image map.
     */
    public static handleUiTexturesUpload(): void {
        const fileInput = document.getElementById("ui_textures_importer") as HTMLInputElement | null;
        if (!fileInput?.files) return;

        const files = Array.from(fileInput.files);
        if (files.length === 0) return;

        const firstRelativePath = files[0]?.webkitRelativePath || (files[0] as any)?._webkitRelativePath || "";
        const firstDir = firstRelativePath.split("/")[0];
        if (firstRelativePath && firstDir !== "ui") {
            new Notification(
                `Selected folder is "${firstDir}". Texture paths may need to start with "${firstDir}" in-game.`,
                5000,
                "warning"
            );
        }

        void FileUploader.processFileUpload(files);
        fileInput.value = "";
    }

    public static async processFileUpload(files: File[]): Promise<void> {
        for (const file of files) {
            this.addToFileSystem(file);
        }
        console.log(GLOBAL_FILE_SYSTEM);

        const pngFiles = files.filter((file) => /\.(png|jpe?g|webp)$/i.test(file.name));
        let loadedCount = 0;

        const tasks = pngFiles.map(async (pngFile) => {
            const baseName = this.getFilePath(pngFile).replace(/\.[^.]*$/, "");

            try {
                const imageData = await this.readImageAsImageData(pngFile);
                const existingData = images.get(baseName) ?? {};
                existingData.png = imageData;
                images.set(baseName, existingData);

                const jsonFile = files.find((file) => this.getFilePath(file).toLowerCase() === `${baseName}.json`.toLowerCase());
                if (jsonFile) {
                    try {
                        existingData.json = await this.readJsonFile(jsonFile);
                    } catch (error) {
                        new Notification(`Could not read ${jsonFile.name}: invalid JSON`, 4000, "warning");
                    }
                }
                loadedCount++;
            } catch (error) {
                new Notification(`Could not load texture: ${pngFile.name}`, 4000, "error");
                console.error(`Error loading texture ${pngFile.name}:`, error);
            }
        });

        await Promise.all(tasks);
        if (loadedCount > 0) new Notification(`${loadedCount} texture(s) loaded`, 2500, "notif");
        else new Notification("No supported texture files were loaded", 3500, "warning");
    }

    public static readJsonFile(file: File): Promise<any> {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => {
                try {
                    resolve(JSON.parse(reader.result as string));
                } catch (err) {
                    reject(err);
                }
            };
            reader.onerror = reject;
            reader.readAsText(file);
        });
    }

    private static readImageAsImageData(file: File): Promise<ImageData> {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => {
                const img = new Image();
                img.onload = () => {
                    const canvas = document.createElement("canvas");
                    canvas.width = img.width;
                    canvas.height = img.height;
                    const ctx = canvas.getContext("2d")!;
                    ctx.drawImage(img, 0, 0);
                    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
                    resolve(imageData);
                };
                img.onerror = reject;
                img.src = reader.result as string;
            };
            reader.onerror = reject;
            reader.readAsDataURL(file);
        });
    }

    public static isFileUploaded(fileName: string): boolean {
        return images.has(fileName);
    }

    public static async getAssetAsFile(path: string, filename: string): Promise<File> {
        const response = await fetch(path);
        const blob = await response.blob();
        const file = new File([blob], filename, { type: blob.type });
        return file;
    }
}
