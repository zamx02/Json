export function parseJsonWithComments(raw: string): any {
    let output = "";
    let inString = false;
    let escaped = false;

    for (let i = 0; i < raw.length; i++) {
        const char = raw[i]!;
        const next = raw[i + 1];

        if (inString) {
            output += char;
            if (escaped) escaped = false;
            else if (char === "\\") escaped = true;
            else if (char === '"') inString = false;
            continue;
        }

        if (char === '"') {
            inString = true;
            output += char;
            continue;
        }

        if (char === "/" && next === "/") {
            i += 2;
            while (i < raw.length && raw[i] !== "\n" && raw[i] !== "\r") i++;
            if (i < raw.length) output += raw[i];
            continue;
        }

        if (char === "/" && next === "*") {
            i += 2;
            while (i < raw.length && !(raw[i] === "*" && raw[i + 1] === "/")) {
                if (raw[i] === "\n" || raw[i] === "\r") output += raw[i];
                i++;
            }
            i++;
            continue;
        }

        output += char;
    }

    return JSON.parse(output.trim());
}
