type MobileView = "editor" | "elements" | "properties" | "code";

const nav = document.getElementById("mobile-nav");
const mobileQuery = window.matchMedia("(max-width: 900px)");
const validViews: MobileView[] = ["editor", "elements", "properties", "code"];

function setView(view: MobileView): void {
    document.body.dataset.mobileView = view;

    nav?.querySelectorAll<HTMLButtonElement>("[data-mobile-view]").forEach((button) => {
        button.setAttribute("aria-pressed", String(button.dataset.mobileView === view));
    });
}

function updateLayoutMode(): void {
    if (mobileQuery.matches) {
        const currentView = document.body.dataset.mobileView as MobileView | undefined;
        setView(currentView && validViews.includes(currentView) ? currentView : "editor");
    } else {
        delete document.body.dataset.mobileView;
    }
}

nav?.addEventListener("click", (event) => {
    const button = (event.target as HTMLElement).closest<HTMLButtonElement>("button[data-mobile-view]");
    const view = button?.dataset.mobileView as MobileView | undefined;
    if (view && validViews.includes(view)) setView(view);
});

mobileQuery.addEventListener("change", updateLayoutMode);
updateLayoutMode();
