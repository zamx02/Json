type MobileView = "editor" | "elements" | "properties" | "code";

const nav = document.getElementById("mobile-nav");
const mobileQuery = window.matchMedia("(max-width: 900px)");
const validViews: MobileView[] = ["editor", "elements", "properties", "code"];
const viewport = document.getElementById("canvas-viewport") as HTMLElement | null;
const stage = document.getElementById("canvas-stage") as HTMLElement | null;
const canvas = document.getElementById("main_window") as HTMLElement | null;
const zoomSlider = document.getElementById("mobile-zoom") as HTMLInputElement | null;
const zoomValue = document.getElementById("mobile-zoom-value") as HTMLOutputElement | null;
let zoom = 0.3;

function updateZoom(nextZoom: number): void {
    zoom = Math.max(0.15, Math.min(1, nextZoom));
    if (canvas) canvas.style.transform = `scale(${zoom})`;
    if (stage) {
        stage.style.width = `${1506 * zoom}px`;
        stage.style.height = `${850 * zoom}px`;
    }
    if (zoomSlider) zoomSlider.value = String(Math.round(zoom * 100));
    if (zoomValue) zoomValue.value = `${Math.round(zoom * 100)}%`;
}

function fitCanvas(): void {
    if (!viewport) return;
    const available = Math.max(220, viewport.clientWidth - 14);
    updateZoom(Math.min(1, available / 1506));
    viewport.scrollTo({ left: 0, top: 0, behavior: "smooth" });
}

function setView(view: MobileView): void {
    document.body.dataset.mobileView = view;
    nav?.querySelectorAll<HTMLButtonElement>("[data-mobile-view]").forEach((button) => {
        button.setAttribute("aria-pressed", String(button.dataset.mobileView === view));
    });
    if (view === "editor" && mobileQuery.matches) requestAnimationFrame(fitCanvas);
}

function updateLayoutMode(): void {
    if (mobileQuery.matches) {
        const currentView = document.body.dataset.mobileView as MobileView | undefined;
        setView(currentView && validViews.includes(currentView) ? currentView : "editor");
    } else {
        delete document.body.dataset.mobileView;
        updateZoom(1);
    }
}

nav?.addEventListener("click", (event) => {
    const button = (event.target as HTMLElement).closest<HTMLButtonElement>("button[data-mobile-view]");
    const view = button?.dataset.mobileView as MobileView | undefined;
    if (view && validViews.includes(view)) setView(view);
});

zoomSlider?.addEventListener("input", () => updateZoom(Number(zoomSlider.value) / 100));
document.getElementById("mobile-zoom-out")?.addEventListener("click", () => updateZoom(zoom - 0.05));
document.getElementById("mobile-zoom-in")?.addEventListener("click", () => updateZoom(zoom + 0.05));
document.getElementById("mobile-fit")?.addEventListener("click", fitCanvas);
window.addEventListener("resize", () => {
    if (mobileQuery.matches && document.body.dataset.mobileView === "editor") fitCanvas();
});
mobileQuery.addEventListener("change", updateLayoutMode);
updateLayoutMode();
