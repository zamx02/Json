const viewport = document.getElementById("workspace-viewport") as HTMLDivElement | null;
const navigationToggle = document.getElementById("canvas-navigation-toggle") as HTMLButtonElement | null;
const expandToggle = document.getElementById("canvas-expand-toggle") as HTMLButtonElement | null;

const iconUrl = (name: string): string =>
    `https://api.iconify.design/lucide/${name}.svg?color=%23b8eee1&width=18&height=18`;

let navigationMode = false;
let isPanning = false;
let pointerStartX = 0;
let pointerStartY = 0;
let scrollStartLeft = 0;
let scrollStartTop = 0;

function updateNavigationMode(enabled: boolean): void {
    navigationMode = enabled;
    if (!viewport || !navigationToggle) return;

    viewport.dataset.navigation = String(enabled);
    navigationToggle.setAttribute("aria-pressed", String(enabled));
    navigationToggle.title = enabled
        ? "Desativar modo de navegação e voltar a editar os elementos"
        : "Ativar modo de navegação: bloquear os elementos e arrastar a área";

    const icon = navigationToggle.querySelector("img");
    const label = navigationToggle.querySelector("span");
    if (icon) icon.src = iconUrl(enabled ? "lock-open" : "lock");
    if (label) label.textContent = enabled ? "Editar" : "Navegar";

    viewport.classList.remove("is-panning");
    isPanning = false;
}

function updateExpandedMode(enabled: boolean): void {
    if (!expandToggle) return;

    document.body.classList.toggle("workspace-expanded", enabled);
    expandToggle.setAttribute("aria-pressed", String(enabled));
    expandToggle.title = enabled ? "Restaurar layout" : "Expandir área de trabalho";

    const icon = expandToggle.querySelector("img");
    const label = expandToggle.querySelector("span");
    if (icon) icon.src = iconUrl(enabled ? "minimize-2" : "maximize-2");
    if (label) label.textContent = enabled ? "Recolher" : "Expandir";

    if (enabled && navigationMode) {
        // Keep the navigation/lock state while the workspace is expanded.
        updateNavigationMode(true);
    }
}

navigationToggle?.addEventListener("click", () => {
    updateNavigationMode(!navigationMode);
});

expandToggle?.addEventListener("click", () => {
    updateExpandedMode(!document.body.classList.contains("workspace-expanded"));
});

// Escape always restores the normal layout without changing the edit/navigation mode.
document.addEventListener("keydown", (event: KeyboardEvent) => {
    if (event.key === "Escape" && document.body.classList.contains("workspace-expanded")) {
        updateExpandedMode(false);
    }
});

// In navigation mode, drag the viewport instead of selecting or moving JSON UI items.
viewport?.addEventListener("pointerdown", (event: PointerEvent) => {
    if (!navigationMode || (event.target as HTMLElement).closest(".canvas-toolbar")) return;
    if (event.button !== 0 && event.pointerType !== "touch") return;

    isPanning = true;
    pointerStartX = event.clientX;
    pointerStartY = event.clientY;
    scrollStartLeft = viewport.scrollLeft;
    scrollStartTop = viewport.scrollTop;
    viewport.classList.add("is-panning");
    viewport.setPointerCapture(event.pointerId);
    event.preventDefault();
});

viewport?.addEventListener("pointermove", (event: PointerEvent) => {
    if (!navigationMode || !isPanning) return;
    viewport.scrollLeft = scrollStartLeft - (event.clientX - pointerStartX);
    viewport.scrollTop = scrollStartTop - (event.clientY - pointerStartY);
});

function stopPanning(event: PointerEvent): void {
    if (!isPanning) return;
    isPanning = false;
    viewport?.classList.remove("is-panning");
    if (viewport?.hasPointerCapture(event.pointerId)) {
        viewport.releasePointerCapture(event.pointerId);
    }
}

viewport?.addEventListener("pointerup", stopPanning);
viewport?.addEventListener("pointercancel", stopPanning);
viewport?.addEventListener("lostpointercapture", () => {
    isPanning = false;
    viewport?.classList.remove("is-panning");
});

