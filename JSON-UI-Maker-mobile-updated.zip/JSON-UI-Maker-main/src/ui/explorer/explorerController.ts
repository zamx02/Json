import { config } from "../../CONFIG.js";
import { Builder, GlobalElementMapValue, GLOBAL_ELEMENT_MAP, panelContainer, selectedElement } from "../../index.js";
import { GeneralUtil } from "../../util/generalUtil.js";
import { classToTagName } from "../../converterTypes/HTMLClassToJonUITypes.js";
import { StringUtil } from "../../util/stringUtil.js";
import { undoRedoManager } from "../../keyboard/undoRedo.js";

const textElementIdMap: Map<string, HTMLDivElement> = new Map();
const explorerBaseElement = document.getElementById("explorer")!;
let pointerDragId: string | undefined;
let pointerDropId: string | undefined;
let pointerStart: { x: number; y: number } | undefined;
let pointerDragReady = false;
let skipNextClick = false;
let holdTimer: number | undefined;

function positionNode(element: GlobalElementMapValue): HTMLElement {
    return (element as any).basePanel instanceof HTMLElement ? (element as any).basePanel : element.getMainHTMLElement();
}

function canContain(target: GlobalElementMapValue): boolean {
    const node = target.getMainHTMLElement();
    return node === config.rootElement || node.classList.contains("draggable-panel") ||
        node.classList.contains("draggable-collection_panel") || node.classList.contains("draggable-scrolling_panel");
}

function clearDropTargets(): void {
    explorerBaseElement.querySelectorAll(".drop-target").forEach((node) => node.classList.remove("drop-target"));
}

export class ExplorerController {
    static constructTextElement(text: string, hasChildren: boolean): HTMLDivElement {
        const div = document.createElement("div");
        div.classList.add("explorerDiv");
        const textDiv = document.createElement("button");
        textDiv.type = "button";
        textDiv.classList.add("explorerText");
        textDiv.textContent = text;
        if (hasChildren) {
            const arrow = document.createElement("span");
            arrow.className = "explorerArrow";
            arrow.setAttribute("aria-hidden", "true");
            arrow.textContent = "▾";
            div.appendChild(arrow);
        }
        const visibility = document.createElement("button");
        visibility.type = "button";
        visibility.className = "explorerVisibilityToggle";
        visibility.title = "Mostrar ou ocultar elemento";
        visibility.textContent = "◉";
        div.appendChild(textDiv);
        div.appendChild(visibility);
        return div;
    }

    static updateExplorer(): void {
        if (!config.rootElement) return;
        ExplorerController.reset();
        textElementIdMap.clear();
        const rootClassElement = GeneralUtil.elementToClassElement(config.rootElement)!;
        ExplorerController.tree(rootClassElement, explorerBaseElement as HTMLDivElement);
        ExplorerController.selectedElementUpdate();
    }

    static reset(): void {
        explorerBaseElement.innerHTML = "";
    }

    static tree(classElement: GlobalElementMapValue, lastTextElement: HTMLDivElement, depth = 0): void {
        const mainElement = classElement.getMainHTMLElement();
        const isRoot = mainElement.dataset.id === config.rootElement?.dataset.id;
        const filteredChildren: HTMLElement[] = [];
        for (const child of Array.from(mainElement.children) as HTMLElement[]) {
            const target = child.dataset.skip === "true" ? child.firstElementChild as HTMLElement | null : child;
            if (target?.dataset.id) filteredChildren.push(target);
        }

        const type = classToTagName.get(mainElement.classList[0]!) ?? "elemento";
        const formattedType = type.replace(/^([a-z])/, (_, c) => c.toUpperCase()).replace(/_([a-z])/g, (_, c) => " " + c.toUpperCase());
        const row = ExplorerController.constructTextElement(formattedType, filteredChildren.length > 0);
        row.dataset.elementId = mainElement.dataset.id!;
        row.style.paddingLeft = `${Math.max(0, depth * 12)}px`;
        const label = row.querySelector<HTMLButtonElement>(".explorerText")!;
        const arrow = row.querySelector<HTMLElement>(".explorerArrow");
        const visibility = row.querySelector<HTMLButtonElement>(".explorerVisibilityToggle")!;

        visibility.onclick = (event) => {
            event.stopPropagation();
            if (visibility.textContent === "◉") {
                visibility.textContent = "○";
                classElement.hide();
            } else {
                visibility.textContent = "◉";
                classElement.show();
            }
        };

        if (arrow) {
            arrow.onclick = (event) => {
                event.stopPropagation();
                const expanded = arrow.textContent === "▾";
                arrow.textContent = expanded ? "▸" : "▾";
                Array.from(row.children).forEach((child) => {
                    if (child.classList.contains("explorerDiv")) (child as HTMLElement).style.display = expanded ? "none" : "block";
                });
            };
        }

        if (isRoot) {
            row.classList.add("explorerRoot");
            const lock = document.createElement("span");
            lock.className = "explorerLocked";
            lock.textContent = "RAIZ";
            row.appendChild(lock);
        } else {
            label.onclick = (event) => {
                if (skipNextClick) {
                    skipNextClick = false;
                    event.preventDefault();
                    return;
                }
                classElement.select(event);
                ExplorerController.selectedElementUpdate();
            };
            label.draggable = true;
            label.addEventListener("dragstart", (event) => {
                if (!event.dataTransfer) return;
                event.dataTransfer.setData("text/plain", mainElement.dataset.id!);
                event.dataTransfer.effectAllowed = "move";
                pointerDragId = mainElement.dataset.id!;
                row.classList.add("is-dragging");
            });
            label.addEventListener("dragend", () => {
                pointerDragId = undefined;
                row.classList.remove("is-dragging");
                clearDropTargets();
            });
        }

        row.addEventListener("dragover", (event) => {
            const sourceId = pointerDragId || (event as DragEvent).dataTransfer?.getData("text/plain");
            const source = sourceId ? GLOBAL_ELEMENT_MAP.get(sourceId) : undefined;
            if (!source || !canContain(classElement) || source === classElement || source.getMainHTMLElement().contains(mainElement)) return;
            event.preventDefault();
            event.stopPropagation();
            clearDropTargets();
            row.classList.add("drop-target");
            if ((event as DragEvent).dataTransfer) (event as DragEvent).dataTransfer!.dropEffect = "move";
        });
        row.addEventListener("drop", (event) => {
            event.preventDefault();
            event.stopPropagation();
            const id = (event as DragEvent).dataTransfer?.getData("text/plain") || pointerDragId;
            if (id) ExplorerController.moveElement(id, mainElement.dataset.id!);
            clearDropTargets();
            pointerDragId = undefined;
        });

        // Touch: press and hold an item, then drag it into a compatible panel.
        label.addEventListener("pointerdown", (event) => {
            if (event.pointerType === "mouse" || isRoot) return;
            pointerStart = { x: event.clientX, y: event.clientY };
            try { label.setPointerCapture(event.pointerId); } catch { /* captura pode não estar disponível */ }
            pointerDragReady = false;
            pointerDragId = mainElement.dataset.id!;
            holdTimer = window.setTimeout(() => {
                pointerDragReady = true;
                skipNextClick = true;
                row.classList.add("is-dragging");
                if (navigator.vibrate) navigator.vibrate(20);
            }, 420);
        });
        label.addEventListener("pointermove", (event) => {
            if (!pointerStart || !pointerDragId) return;
            if (!pointerDragReady && Math.hypot(event.clientX - pointerStart.x, event.clientY - pointerStart.y) > 10) {
                if (holdTimer) window.clearTimeout(holdTimer);
                pointerStart = undefined;
                pointerDragId = undefined;
                return;
            }
            if (!pointerDragReady) return;
            const targetRow = document.elementFromPoint(event.clientX, event.clientY)?.closest<HTMLElement>(".explorerDiv[data-element-id]");
            clearDropTargets();
            if (targetRow?.dataset.elementId) {
                const target = GLOBAL_ELEMENT_MAP.get(targetRow.dataset.elementId);
                const source = GLOBAL_ELEMENT_MAP.get(pointerDragId);
                if (target && source && canContain(target) && source !== target && !source.getMainHTMLElement().contains(target.getMainHTMLElement())) {
                    pointerDropId = targetRow.dataset.elementId;
                    targetRow.classList.add("drop-target");
                }
            }
        });
        const finishTouchMove = () => {
            if (holdTimer) window.clearTimeout(holdTimer);
            if (pointerDragReady && pointerDragId && pointerDropId) ExplorerController.moveElement(pointerDragId, pointerDropId);
            if (pointerDragReady) skipNextClick = true;
            row.classList.remove("is-dragging");
            clearDropTargets();
            pointerStart = undefined;
            pointerDragReady = false;
            pointerDragId = undefined;
            pointerDropId = undefined;
        };
        label.addEventListener("pointerup", finishTouchMove);
        label.addEventListener("pointercancel", finishTouchMove);

        lastTextElement.appendChild(row);
        textElementIdMap.set(mainElement.dataset.id!, row);
        for (const childHtml of filteredChildren) {
            const child = GeneralUtil.elementToClassElement(childHtml);
            if (child) ExplorerController.tree(child, row, depth + 1);
        }
    }

    static moveElement(elementId: string, targetId: string, recordUndo = true): boolean {
        const element = GLOBAL_ELEMENT_MAP.get(elementId);
        const targetClass = GLOBAL_ELEMENT_MAP.get(targetId);
        if (!element || !targetClass || element === targetClass || !canContain(targetClass)) return false;
        const sourceMain = element.getMainHTMLElement();
        const targetMain = targetClass.getMainHTMLElement();
        if (sourceMain.contains(targetMain)) return false;

        const childType = sourceMain.classList.contains("draggable-scrolling_panel") ? "scrolling_panel" :
            sourceMain.classList.contains("draggable-collection_panel") ? "collection_panel" :
            sourceMain.classList.contains("draggable-label") ? "label" :
            sourceMain.classList.contains("draggable-button") ? "button" :
            sourceMain.classList.contains("draggable-canvas") ? "canvas" : "panel";
        if (!Builder.isValidPath(targetMain, childType as any)) return false;

        const movingNode = positionNode(element);
        const oldParent = (element as any).container as HTMLElement;
        if (!oldParent || oldParent === targetMain) return false;
        const oldRect = oldParent.getBoundingClientRect();
        const newRect = targetMain.getBoundingClientRect();
        const oldLeft = StringUtil.cssDimToNumber(movingNode.style.left);
        const oldTop = StringUtil.cssDimToNumber(movingNode.style.top);
        const oldParentId = oldParent.dataset.id ?? config.rootElement?.dataset.id ?? "";
        const previousState = { parentId: oldParentId, left: oldLeft, top: oldTop };
        const left = Math.max(0, Math.min(newRect.width || 1500, (oldLeft / Math.max(1, oldRect.width)) * (newRect.width || 1500)));
        const top = Math.max(0, Math.min(newRect.height || 844, (oldTop / Math.max(1, oldRect.height)) * (newRect.height || 844)));

        targetMain.appendChild(movingNode);
        (element as any).container = targetMain;
        movingNode.style.left = `${left}px`;
        movingNode.style.top = `${top}px`;
        movingNode.style.zIndex = String(2 * GeneralUtil.getElementDepth(targetMain, panelContainer));

        if (recordUndo) undoRedoManager.push({ type: "move", elementId, previousState, newState: { parentId: targetId, left, top } });
        Builder.updateExplorer();
        return true;
    }

    static selectedElementUpdate(): void {
        explorerBaseElement.querySelector(".selected")?.classList.remove("selected");
        if (!selectedElement) return;
        const row = textElementIdMap.get(selectedElement.dataset.id!);
        const text = row?.querySelector<HTMLButtonElement>(".explorerText");
        text?.classList.add("selected");
        let parent = row?.parentElement;
        while (parent && parent !== explorerBaseElement) {
            if (parent.classList.contains("explorerDiv")) {
                parent.style.display = "block";
                const arrow = parent.querySelector<HTMLElement>(":scope > .explorerArrow");
                if (arrow) arrow.textContent = "▾";
            }
            parent = parent.parentElement;
        }
    }
}
