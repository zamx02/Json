import { config } from "../../CONFIG.js";
import { GLOBAL_FILE_SYSTEM } from "../../index.js";

const modal: HTMLElement = document.getElementById("modalChooseImage") as HTMLElement;
const closeBtn: HTMLElement = document.getElementById("modalChooseImageClose") as HTMLElement;
const form: HTMLDivElement = document.getElementsByClassName("modalChooseImageForm")[0] as HTMLDivElement;

class ChooseImageFileTree {
    static constructTextElement(text: string, hasChildren: boolean, hasNineslice: boolean = false): HTMLDivElement {
        const div = document.createElement("div");
        div.classList.add("explorerDiv");

        const textDiv = document.createElement("div");
        textDiv.classList.add("explorerText");
        textDiv.textContent = text;

        if (hasChildren) {
            const arrowDiv = document.createElement("img") as HTMLImageElement;
            arrowDiv.src = "assets/arrow_down.webp";
            arrowDiv.classList.add("explorerArrow");
            arrowDiv.style.marginLeft = "5px";
            div.appendChild(arrowDiv);
        }

        div.appendChild(textDiv);

        if (hasNineslice) {
            const ninesliceImg = document.createElement("img") as HTMLImageElement;
            ninesliceImg.src = "icons/nineslice.webp";
            ninesliceImg.classList.add("explorerHasNineslice");
            div.appendChild(ninesliceImg);
        }

        return div;
    }

    static tree(fileStructureCurrentDir: any, lastTextElement: HTMLDivElement, depth: number = 0): void {
        console.log("Image Dir Tree", depth, fileStructureCurrentDir);
        const nextDirs = Object.keys(fileStructureCurrentDir);

        const acceptedTypes = ["png", "jpg", "jpeg", "webp"];

        for (let nextDir of nextDirs) {
            const hasChildren: boolean = Object.keys(fileStructureCurrentDir[nextDir]).length > 0;

            if (hasChildren) {
                const textElement = ChooseImageFileTree.constructTextElement(nextDir, hasChildren);
                textElement.style.left = `${config.magicNumbers.explorer.folderIndentation - (depth === 0 ? 20 : 0)}px`;

                const textArrowElement = textElement.querySelector<HTMLImageElement>(".explorerArrow")!;

                // Button logic
                textArrowElement.onclick = (e: MouseEvent) => {
                    e.stopPropagation();
                    e.preventDefault();

                    textArrowElement.src = textArrowElement.src.endsWith("assets/arrow_down.webp") ? "assets/arrow_right.webp" : "assets/arrow_down.webp";

                    // Toggles the visibility of the children
                    for (const child of Array.from(textElement.children) as HTMLElement[]) {
                        console.log(child);
                        if (child.classList.contains("explorerDiv")) {
                            console.log(child, 5);
                            child.style.display = child.style.display === "none" ? "block" : "none";
                        }
                    }
                };

                lastTextElement.appendChild(textElement);
                this.tree(fileStructureCurrentDir[nextDir], textElement, depth + 1);
            } else {
                const fileType = nextDir.split(".").pop();
                console.log(fileType);
                if (!fileType || !acceptedTypes.includes(fileType)) continue;

                console.log(nextDir);

                const baseName = nextDir.replace(/\.[^.]+$/, "");
                const hasNineslice = nextDirs.some((dir) => dir === `${baseName}.json`);

                const textElement = ChooseImageFileTree.constructTextElement(nextDir, hasChildren, hasNineslice);
                textElement.style.left = `${config.magicNumbers.explorer.nonFolderIndentation - (depth === 0 ? 20 : 0)}px`;

                lastTextElement.appendChild(textElement);
            }
        }
    }
}

// Valid image extensions used in multiple places
const VALID_IMAGE_EXTENSIONS = ["png", "jpg", "jpeg", "webp"] as const;

// Recursively collect all image paths (without extension) from the virtual file system
function collectImagePaths(fsObj: any, currentPath: string = ""): string[] {
    const paths: string[] = [];
    for (const key of Object.keys(fsObj)) {
        const value = fsObj[key];
        const joinedPath = currentPath ? `${currentPath}/${key}` : key;
        const ext = key.split(".").pop();
        // If we have children this is a directory
        if (typeof value === "object" && value !== null && Object.keys(value).length > 0) {
            paths.push(...collectImagePaths(value, joinedPath));
        } else if (ext && (VALID_IMAGE_EXTENSIONS as readonly string[]).includes(ext)) {
            // Strip extension to stay consistent with existing behaviour
            paths.push(joinedPath.replace(/\.[^/.]+$/, ""));
        }
    }
    return paths;
}

export async function chooseImageModal(): Promise<string> {
    return new Promise((resolve, reject) => {
        // Clean up any existing search wrapper first
        const existingSearchWrapper = form.parentElement?.querySelector(".chooseImageSearchWrapper");
        if (existingSearchWrapper) {
            existingSearchWrapper.remove();
        }
        
        // Clear previous content
        form.innerHTML = "";

        // -------------------- NEW: Search UI --------------------
        const searchWrapper = document.createElement("div");
        searchWrapper.classList.add("chooseImageSearchWrapper");

        const searchInput = document.createElement("input");
        searchInput.type = "text";
        searchInput.placeholder = "Search images...";
        searchInput.classList.add("chooseImageSearchInput");
        searchWrapper.appendChild(searchInput);

        const dropdown = document.createElement("select");
        dropdown.size = 6; // show few results at once
        dropdown.classList.add("chooseImageSearchDropdown");
        dropdown.style.display = "none"; // hidden until there is query
        searchWrapper.appendChild(dropdown);

        // Insert search UI before the tree container (form)
        form.parentElement?.insertBefore(searchWrapper, form);

        // Prepare enhanced file system with user uploaded presets
        const enhancedFileSystem = enhanceFileSystemWithUserPresets();
        
        // Prepare list of all image paths (without extension) once
        const allImagePaths = collectImagePaths(enhancedFileSystem);

        console.log('All available images:', allImagePaths);

        const updateDropdown = () => {
            const query = searchInput.value.toLowerCase();
            // Clear previous options
            dropdown.innerHTML = "";
            if (!query) {
                dropdown.style.display = "none";
                return;
            }
            const filtered = allImagePaths.filter((p) => p.toLowerCase().includes(query)).slice(0, 50); // limit 50 results
            if (filtered.length === 0) {
                dropdown.style.display = "none";
                return;
            }
            for (const path of filtered) {
                const option = document.createElement("option");
                option.value = path;
                option.textContent = path;
                dropdown.appendChild(option);
            }
            dropdown.style.display = "block";
        };

        searchInput.addEventListener("input", updateDropdown);

        dropdown.addEventListener("change", () => {
            const selected = dropdown.value;
            if (selected) {
                cleanup();
                resolve(selected);
            }
        });

        // -------------------- END Search UI --------------------

        // Build tree view with enhanced file system
        ChooseImageFileTree.tree(enhancedFileSystem, form);

        const handleClick = (event: MouseEvent) => {
            const element = event.composedPath()[0] as HTMLElement | undefined;
            if (!element?.classList.contains("explorerText")) return;

            const fileName = element.textContent?.trim();
            if (!fileName) return;

            // Handle both file system paths and direct image names (from user presets)
            const validExtensions = ["png", "jpg", "jpeg", "webp"];
            const isImage = validExtensions.some((ext) => fileName.endsWith(`.${ext}`));
            
            // If it's a direct image name (user preset), return it directly
            if (!isImage) {
                cleanup();
                resolve(fileName);
                return;
            }

            // Build directory chain for file system images
            const parents: string[] = [];
            let current = element.parentElement;

            while (current && current.classList.contains("explorerDiv")) {
                const parentText = current.querySelector(".explorerText")?.textContent?.trim();
                if (parentText) parents.push(parentText);
                current = current.parentElement;
            }

            const filePath = parents.reverse().join("/").replace(/\.[^/.]+$/, "");
            console.log(`File Path: ${filePath}`);

            cleanup();
            resolve(filePath);
        };

        const handleClose = () => {
            cleanup();
            reject(new Error("Modal closed"));
        };

        const handleWindowClick = (event: MouseEvent) => {
            if (event.target === modal) {
                cleanup();
                reject(new Error("Modal closed"));
            }
        };

        const cleanup = () => {
            document.removeEventListener("click", handleClick);
            closeBtn.removeEventListener("click", handleClose);
            window.removeEventListener("click", handleWindowClick);
            modal.style.display = "none";
            // Remove the search wrapper if it exists
            const existingSearchWrapper = form.parentElement?.querySelector(".chooseImageSearchWrapper");
            if (existingSearchWrapper) {
                existingSearchWrapper.remove();
            }
            form.innerHTML = "";
        };

        // Add all listeners
        document.addEventListener("click", handleClick);
        closeBtn.addEventListener("click", handleClose);
        window.addEventListener("click", handleWindowClick);

        modal.style.display = "block";
    });
}

/**
 * Enhances the file system by merging user uploaded presets into the main structure
 */
function enhanceFileSystemWithUserPresets(): any {
    // Clone the original file system
    const enhanced = JSON.parse(JSON.stringify(GLOBAL_FILE_SYSTEM));
    
    // Add user uploaded presets to the root level
    const userImages = (window as any).images;
    if (userImages && userImages.size > 0) {
        console.log('Integrating user presets into main file system');
        
        for (const [key, value] of userImages) {
            if (value && (value.png || value.json)) {
                console.log('Adding user preset to file system:', key);
                
                // Add the image file
                enhanced[`${key}.png`] = {};
                
                // Add nineslice indicator if JSON exists
                if (value.json) {
                    enhanced[`${key}.json`] = {};
                }
            }
        }
    }
    
    return enhanced;
}

/**
 * Shows a preview of the selected image with NineSlice information if available
 */
function showImagePreview(imageName: string, imageData: any): void {
    // Create a preview modal or notification
    const preview = document.createElement("div");
    preview.className = "image-preview";
    preview.style.cssText = `
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: rgba(0,0,0,0.9);
        padding: 20px;
        border-radius: 8px;
        color: white;
        z-index: 10000;
        max-width: 400px;
        text-align: center;
    `;
    
    let previewContent = `<h3>Selected: ${imageName}</h3>`;
    
    if (imageData.png) {
        previewContent += `<p>✅ PNG texture loaded</p>`;
    }
    
    if (imageData.json) {
        previewContent += `<p>✅ NineSlice configuration found</p>`;
        if (imageData.json.nineslice_size) {
            previewContent += `<p>Size: [${imageData.json.nineslice_size.join(', ')}]</p>`;
        }
        if (imageData.json.base_size) {
            previewContent += `<p>Base Size: [${imageData.json.base_size.join(', ')}]</p>`;
        }
    }
    
    previewContent += `<button onclick="this.parentElement.remove()" style="
        margin-top: 10px;
        padding: 8px 16px;
        background: #007bff;
        color: white;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    ">Close Preview</button>`;
    
    preview.innerHTML = previewContent;
    document.body.appendChild(preview);
    
    // Auto-remove after 3 seconds
    setTimeout(() => {
        if (preview.parentNode) {
            preview.remove();
        }
    }, 3000);
}
