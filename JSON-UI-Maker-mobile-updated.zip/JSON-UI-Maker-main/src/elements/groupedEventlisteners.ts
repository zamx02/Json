import { GLOBAL_ELEMENT_MAP, GlobalElementMapValue, draggedElement, resizedElement } from "../index.js";

let pendingEvent: PointerEvent | null = null;
let ticking = false;
let activePointerId: number | null = null;
let touchSession: {
    element: GlobalElementMapValue;
    pointerId: number;
    pointerType: string;
    startX: number;
    startY: number;
    moved: boolean;
} | null = null;

function getElementFromTarget(target: EventTarget | null): GlobalElementMapValue | undefined {
    if (!(target instanceof HTMLElement)) return undefined;
    const element = target.closest<HTMLElement>("[data-id]");
    const id = element?.dataset.id;
    return id ? GLOBAL_ELEMENT_MAP.get(id) : undefined;
}

document.addEventListener("pointerdown", (event: PointerEvent) => {
    if (activePointerId !== null && activePointerId !== event.pointerId) return;
    activePointerId = event.pointerId;
    const target = event.target instanceof HTMLElement ? event.target : null;
    if (!target || target.closest(".resize-handle") || resizedElement) {
        touchSession = null;
        return;
    }

    const element = draggedElement ?? getElementFromTarget(target);
    if (!element) {
        touchSession = null;
        return;
    }

    touchSession = {
        element,
        pointerId: event.pointerId,
        pointerType: event.pointerType,
        startX: event.clientX,
        startY: event.clientY,
        moved: false,
    };
}, true);

document.addEventListener("pointermove", (event: PointerEvent) => {
    if (activePointerId !== null && event.pointerId !== activePointerId) return;

    if (touchSession && touchSession.pointerId === event.pointerId) {
        const distance = Math.hypot(event.clientX - touchSession.startX, event.clientY - touchSession.startY);
        if (distance > 8) touchSession.moved = true;
    }

    if (!draggedElement && !resizedElement) return;
    pendingEvent = event;

    if (!ticking) {
        requestAnimationFrame(() => {
            if (pendingEvent) {
                if (draggedElement) draggedElement.drag(pendingEvent);
                if (resizedElement) {
                    const resizeTarget = resizedElement as GlobalElementMapValue & { outlineResize?: (e: PointerEvent) => void };
                    if (typeof resizeTarget.outlineResize === "function") resizeTarget.outlineResize(pendingEvent);
                    else resizedElement.resize(pendingEvent);
                }
                pendingEvent = null;
            }
            ticking = false;
        });
        ticking = true;
    }
});

function finishPointer(event: PointerEvent): void {
    if (activePointerId !== null && event.pointerId !== activePointerId) return;

    const activeDrag = draggedElement;
    const activeResize = resizedElement;
    const session = touchSession;

    if (activeDrag) {
        activeDrag.stopDrag();
        const pressable = activeDrag as GlobalElementMapValue & { stopPress?: () => void };
        pressable.stopPress?.();

        if (event.type === "pointerup" && session && session.pointerId === event.pointerId && session.pointerType === "touch" && !session.moved && !activeResize) {
            activeDrag.select(event);
        }
    }

    if (activeResize) {
        const resizeTarget = activeResize as GlobalElementMapValue & { outlineResize?: (e: PointerEvent) => void };
        if (typeof resizeTarget.outlineResize === "function") activeResize.resize(event);
        const stopResize = activeResize.stopResize as (event?: PointerEvent) => void;
        stopResize.call(activeResize, event);
    }

    pendingEvent = null;
    touchSession = null;
    activePointerId = null;
}

document.addEventListener("pointerup", finishPointer);
document.addEventListener("pointercancel", finishPointer);
