# Créditos de texturas

Os pequenos ícones pixelados da interface são carregados diretamente do repositório público **Mojang/bedrock-samples**, na pasta `resource_pack/textures/items/`. Os arquivos continuam sendo propriedade de Mojang Studios / Microsoft e são usados como referências visuais de itens vanilla do Minecraft.

Este editor é um projeto independente e não é afiliado nem endossado pela Mojang Studios ou Microsoft. O acesso aos ícones requer conexão com a internet.
