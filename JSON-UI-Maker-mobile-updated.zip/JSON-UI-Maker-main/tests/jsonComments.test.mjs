import test from "node:test";
import assert from "node:assert/strict";
import { parseJsonWithComments } from "../dist/util/jsonComments.js";

test("removes line and block comments", () => {
    const source = `{
        // namespace comment
        "namespace": "sample",
        /* display name */
        "title": "Example"
    }`;
    assert.deepEqual(parseJsonWithComments(source), { namespace: "sample", title: "Example" });
});

test("preserves URLs and slash characters inside strings", () => {
    const source = `{
        "url": "https://example.com/path//segment",
        "asset": "textures/ui/icon.png"
    }`;
    assert.deepEqual(parseJsonWithComments(source), {
        url: "https://example.com/path//segment",
        asset: "textures/ui/icon.png"
    });
});

test("preserves comment markers inside quoted text and escaped quotes", () => {
    const source = String.raw`{"text":"say \"hello\" // keep this", "note":"/* still text */"}`;
    assert.deepEqual(parseJsonWithComments(source), {
        text: 'say "hello" // keep this',
        note: "/* still text */"
    });
});

test("rejects invalid JSON after comments are removed", () => {
    assert.throws(() => parseJsonWithComments('{ "a": 1, }'), SyntaxError);
});
